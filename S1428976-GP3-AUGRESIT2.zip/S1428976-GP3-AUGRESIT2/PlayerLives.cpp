#include "PlayerLives.h"


PlayerLives::PlayerLives(TransformManager position)
{

}

void PlayerLives::Update()
{

}

PlayerLives::~PlayerLives()
{

}

